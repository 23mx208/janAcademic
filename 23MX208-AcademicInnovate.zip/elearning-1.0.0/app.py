from flask import Flask, render_template, request, redirect, flash, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime

app = Flask(__name__)
app.secret_key = '3f6b9cc0d5f1e4bba0c7af6c67c4d7fe'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['ALLOWED_EXTENSIONS'] = {'gif', 'jpeg', 'jpg', 'png'}
db = SQLAlchemy(app)

# Define User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), nullable=False)
    
    # Relationship to projects
    projects = db.relationship('Project', backref='user', lazy=True)

# Define Project model
class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    file = db.Column(db.String(200), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    status = db.Column(db.String(50), nullable=False, default='pending')
class Comment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    comment = db.Column(db.Text, nullable=False)
    
    # Foreign key linking to Project table
    project_id = db.Column(db.Integer, db.ForeignKey('project.id'), nullable=False)
    
    # Foreign key linking to User table
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationship to access project and user objects
    project = db.relationship('Project', backref=db.backref('comments', lazy=True))
    user = db.relationship('User', backref=db.backref('comments', lazy=True))

    # Optional: timestamp for when the comment was made
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
from flask_migrate import Migrate
migrate = Migrate(app, db)

def init_db():
    db.create_all()
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirmPassword']
        role = request.form['role']
        
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('signup'))
        try:
            new_user = User(name=name, email=email, password=password, role=role)
            db.session.add(new_user)
            db.session.commit()
            flash('You have successfully registered!', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            flash(f'Error: {str(e)}', 'danger')

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = User.query.filter_by(email=email).first()
        
        if user and user.password == password:  # Directly compare passwords
            session['user_id'] = user.id
            session['email'] = email
            session['role'] = user.role

            if user.role == 'admin':
                return redirect(url_for('admin_home'))
            elif user.role == 'user':
                return redirect(url_for('index'))
        else:
            flash('Invalid email or password', 'danger')
        
    return render_template('login.html')

from sqlalchemy import desc
from sqlalchemy import func

@app.route('/')
def index():
    webdesign_count = Project.query.filter_by(category='web_design').count()
    android_count = Project.query.filter_by(category='android_development').count()
    python_count = Project.query.filter_by(category='python_projects').count()
    java_count = Project.query.filter_by(category='java_projects').count()
    category_counts = db.session.query(Project.title, Project.file, Project.category, func.count(Project.category)).group_by(Project.category).all()
    row=Project.query.order_by(desc(Project.id)).all()
    return render_template('index.html',webdesign_count=webdesign_count,android_count=android_count,
    python_count=python_count,java_count=java_count,row=row,category_counts=category_counts)
@app.route('/view')
def view_project():
    row=Project.query.order_by(desc(Project.id)).all()
    return render_template('view.html',row=row)

@app.route('/admin_home')
def admin_home():
    users = User.query.all()
    project = Project.query.all()
    total_projects = Project.query.count()
    total_users = User.query.count()
    return render_template('admin_home.html',total_users=total_users,users=users,project=project,total_projects=total_projects)

@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/accept')
def accept():
    project_id = request.args.get('id')
    
    # Check if project_id exists
    if project_id:
        project = Project.query.get_or_404(project_id)
        project.status = 'Accepted'
        db.session.commit()
        flash(f'Project "{project.title}" has been accepted.', 'success')
    else:
        flash('Project not found', 'danger')
    
    return redirect(url_for('admin_home'))
@app.route('/reject')
def reject():
    project_id = request.args.get('id')
    
    # Check if project_id exists
    if project_id:
        project = Project.query.get_or_404(project_id)
        project.status = 'Rejected'
        db.session.commit()
        flash(f'Project "{project.title}" has been rejected.', 'success')
    else:
        flash('Project not found', 'danger')
    
    return redirect(url_for('admin_home'))
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

app.config['UPLOAD_FOLDER'] = 'static/uploads'

def allowed_file(filename):
    allowed_extensions = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'html'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/upload', methods=['GET', 'POST'])
def upload_project():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        category = request.form['category']
        file = request.files['file']

        # Debug output
        print(f'Title: {title}, Description: {description}, Category: {category}, File: {file.filename}')

        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            user_id = session.get('user_id')
            if user_id is None:
                print('User is not logged in, redirecting to login.')
                return redirect(url_for('login'))

            new_project = Project(
                title=title,
                description=description,
                category=category,
                file=filename,
                user_id=user_id
            )
            db.session.add(new_project)
            try:
                db.session.commit()
                print('Project uploaded successfully!')
            except Exception as e:
                print(f'Error uploading project: {e}')
                db.session.rollback()

            return redirect(url_for('index'))

    return render_template('upload.html')

@app.route('/comment/<int:project_id>', methods=['GET', 'POST'])
def comment(project_id):
    comments = Comment.query.filter(Comment.project_id == project_id).all()
    if request.method == 'POST':
        if 'user_id' not in session:
            flash('Please log in to comment.', 'danger')
            return redirect(url_for('login'))

        comment_text = request.form['comment']
        user_id = session['user_id']
        new_comment = Comment(comment=comment_text, project_id=project_id, user_id=user_id)
        db.session.add(new_comment)
        db.session.commit()
        flash('Comment added successfully!', 'success')
        return redirect(url_for('admin_home'))

    # For GET request, render the comment form
    return render_template('comment.html', project_id=project_id,comments=comments)

@app.route('/link')
def link():
    project_id = request.args.get('id')
    row = Project.query.filter(Project.id == project_id).all()
    return render_template('link.html', row=row)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Recreates all the tables with the new schema
    app.run()
